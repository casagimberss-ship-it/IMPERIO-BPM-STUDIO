# IMPERIO BPM Studio

Aplicación Android nativa para preparar música y puntos Hot Cue antes de trabajar con VirtualDJ.

## Preferencias del proyecto
- Almacenamiento: archivos locales del teléfono mediante el selector seguro de Android (Storage Access Framework).
- 8 Hot Cues.
- Interfaz oscura con acentos violeta y verde.
- Créditos: Dj Lucas Quintana.

## Estado de esta primera base (0.1.0)
Implementado:
- Proyecto Android Kotlin + Jetpack Compose.
- Carga de audio mediante selector del sistema.
- Reproducción, pausa, detener y búsqueda por posición con Android Media3.
- Ocho posiciones Hot Cue por canción durante la sesión.
- Persistencia local básica de las posiciones por URI.
- Workflow de GitHub Actions para generar APK debug y publicarlo como artifact.

Pendiente antes de considerarlo una versión funcional completa:
- Restaurar automáticamente los CUE al volver a abrir una canción.
- Análisis real de BPM y detección de beatgrid.
- Edición de etiquetas y colores.
- Exportador e importador VirtualDJ validado con archivos de base de datos reales.
- Pruebas de integración con una instalación concreta de VirtualDJ.
- Firma de APK release.

## Compilar
Requiere JDK 17 y Gradle 8.9 o compatible con Android Gradle Plugin 8.7.3.

```bash
gradle :app:assembleDebug
```

El APK de depuración queda en:
`app/build/outputs/apk/debug/app-debug.apk`

## Compilación desde GitHub
Sube el contenido de este proyecto a la rama `main` o ejecuta manualmente el workflow
**Build Android APK** desde la pestaña Actions. Descarga el artifact
`imperio-bpm-studio-debug`.

## Compatibilidad VirtualDJ
Esta versión todavía NO exporta datos a VirtualDJ. No debe modificarse `database.xml`
hasta implementar y validar el formato exacto, las rutas de audio y la estrategia de copia
de seguridad. El teléfono no debe intentar escribir directamente en la base de datos
de VirtualDJ alojada en otra computadora.
