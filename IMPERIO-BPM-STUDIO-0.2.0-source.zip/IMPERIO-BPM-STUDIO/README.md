# IMPERIO BPM Studio 0.2.0

Aplicación Android nativa para preparar música con reproducción, 8 Hot Cues y análisis inicial de tempo.

## Incluye en 0.2.0
- Reproductor Android Media3.
- Selección de audio mediante Android Storage Access Framework.
- Persistencia local de 8 Hot Cues por URI de pista.
- Recuperación de Hot Cues al volver a seleccionar la misma pista.
- Guardado inmediato y eliminación individual manteniendo pulsado el botón CUE.
- Analizador BPM que decodifica el audio y estima el pulso mediante cambios de energía y autocorrelación.
- Workflow GitHub Actions para compilar APK debug.

## Analizador BPM
Pulsa **ANALIZAR BPM** con una pista cargada. El análisis requiere unos 8 segundos o más de audio decodificable. La estimación automática puede confundirse con el doble o la mitad del tempo en música con síncopas, breaks o patrones poco marcados; se debe validar escuchando y comparando con el beat. No se presenta un valor cuando no se detecta un pulso estable.

## Hot Cues
- Toque en un CUE vacío: guarda la posición actual.
- Toque en un CUE asignado: salta a esa posición.
- Mantener pulsado un CUE asignado: elimina ese punto.
- Los puntos se almacenan localmente en el teléfono, asociados al URI persistente del archivo.
- El botón **Guardar CUE** fuerza el guardado de la lista actual.

## Compilar
Requiere JDK 17, Android SDK 35 y Gradle 8.9.

```bash
gradle --no-daemon :app:assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions
El workflow `.github/workflows/android.yml` admite ejecución manual (`workflow_dispatch`) y también en cada push a `main`/`master`. Si el repositorio contiene el proyecto como ZIP, intenta extraerlo y localizar `settings.gradle.kts` automáticamente. Si ya está extraído en la raíz, compila directamente.

## Limitaciones conocidas
- El BPM es una estimación automática inicial, no sustituye una revisión de beatgrid profesional.
- Los Hot Cues se guardan en el teléfono. Esta versión todavía no exporta ni sincroniza puntos CUE con la base de datos de VirtualDJ.
- La persistencia depende de que Android mantenga el permiso URI del archivo seleccionado; si el usuario mueve o elimina el archivo, puede ser necesario seleccionarlo de nuevo.
