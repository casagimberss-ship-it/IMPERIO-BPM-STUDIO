# IMPERIO BPM Studio 0.3.0

Aplicación Android nativa para preparar música, reproducir pistas, guardar ocho Hot CUE por canción, estimar BPM desde el audio y exportar las pistas a un pendrive para el flujo de sincronización con VirtualDJ 2025.

## Novedades de 0.3.0 — Exportador USB

- Botón **EXPORTAR MÚSICA + CUE A USB** integrado en la pantalla principal.
- Selector oficial de carpetas Android (Storage Access Framework): seleccionar la raíz del pendrive conectado mediante OTG.
- Copia al pendrive las pistas cargadas/registradas en la app, conservando el nombre de archivo; si hay nombres repetidos agrega sufijos para evitar colisiones.
- Exporta los Hot CUE guardados (hasta 8 por pista), con posición en milisegundos, número, nombre predeterminado y color ARGB.
- Calcula SHA-256 durante la copia para que el sincronizador de Windows pueda verificar que los CUE se asignen al audio correcto.
- Exporta el BPM analizado cuando existe un valor guardado.
- Genera o actualiza `IMPERIO/cues.json` y coloca los audios en `Music/`.
- Usa permisos SAF persistentes y escritura mediante `DocumentFile`, sin depender de rutas de almacenamiento Android restringidas.

## Estructura del pendrive

```text
PENDRIVE/
├── Music/
│   ├── Tema 01.mp3
│   └── Tema 02.mp3
└── IMPERIO/
    └── cues.json
```

El manifiesto es compatible con `IMPERIO-VDJ-SYNC` formato `IMPERIO_CUE`, versión 1. Ejemplo de una marca:

```json
{
  "number": 1,
  "position_ms": 12500,
  "name": "CUE 1",
  "color_argb": 4294901760
}
```

## Cómo exportar

1. Conecta el pendrive al teléfono mediante un adaptador USB OTG.
2. Abre IMPERIO BPM Studio y carga las canciones que quieras llevar. Los CUE se guardan localmente por URI de cada pista.
3. Marca los Hot CUE y analiza el BPM si lo necesitas.
4. Pulsa **EXPORTAR MÚSICA + CUE A USB**.
5. En el selector Android, elige la carpeta raíz del pendrive y confirma el acceso.
6. Espera el mensaje de exportación completada antes de retirar el pendrive.

Para sincronizar en Windows: conecta el pendrive, abre VirtualDJ 2025 para que catalogue las pistas y cree/actualice `VirtualDJ/database.xml`, cierra VirtualDJ y luego ejecuta IMPERIO VDJ SYNC. Haz una copia de seguridad antes de la primera prueba.

## Persistencia y compatibilidad

- Los Hot CUE permanecen en el almacenamiento local de la app y se exportan al USB cuando el usuario lo solicita.
- El exportador incluye pistas registradas en esta versión y pistas antiguas de la versión 0.2.0 que ya tengan CUE guardados.
- El BPM se incluye solo si el análisis produjo y guardó un valor válido.
- El exportador utiliza nombres predeterminados `CUE 1`…`CUE 8` y una paleta fija de colores. La edición de nombres/colores personalizados queda para una siguiente versión.
- Si Android perdió el permiso de lectura de una pista o el archivo fue movido/eliminado, la exportación mostrará un error y habrá que volver a seleccionar esa canción.
- Si se exporta una canción sin CUE, se copia el audio y se incluye con una lista `cues` vacía.

## Compilar

Requiere JDK 17, Android SDK 35 y Gradle compatible con Android Gradle Plugin 8.7.3.

```bash
gradle --no-daemon :app:assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Importante

Este ZIP contiene el código fuente. En el entorno de generación no está disponible Gradle/Android SDK, por lo que esta revisión no se ha compilado ni probado físicamente con un pendrive. Antes de usarlo en una colección musical importante, compila desde Android Studio y prueba con un USB de prueba. La modificación de `VirtualDJ/database.xml` por el sincronizador Windows requiere VirtualDJ cerrado y una copia de seguridad.
