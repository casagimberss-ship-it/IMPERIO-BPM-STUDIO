package com.imperio.bpmstudio

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.security.MessageDigest
import java.util.Locale

internal data class UsbExportResult(val exportedTracks: Int, val exportedCues: Int)

/** Exports the locally saved track CUE data and audio files to a user-selected USB tree. */
internal object UsbExporter {
    private val cueColors = listOf(
        0xFFFF5252.toInt(), 0xFFFFB300.toInt(), 0xFF76FF03.toInt(), 0xFF00E5FF.toInt(),
        0xFF448AFF.toInt(), 0xFFE040FB.toInt(), 0xFFFFFFFF.toInt(), 0xFF69F0AE.toInt()
    )

    fun exportAll(context: Context, prefs: android.content.SharedPreferences, treeUri: Uri): UsbExportResult {
        val root = DocumentFile.fromTreeUri(context, treeUri)
            ?: error("No se pudo abrir la carpeta seleccionada")
        if (!root.canWrite()) error("La carpeta seleccionada no permite escritura")

        val musicDir = root.findFile("Music")?.takeIf { it.isDirectory }
            ?: root.createDirectory("Music") ?: error("No se pudo crear la carpeta Music")
        val imperioDir = root.findFile("IMPERIO")?.takeIf { it.isDirectory }
            ?: root.createDirectory("IMPERIO") ?: error("No se pudo crear la carpeta IMPERIO")

        val tracksJson = JSONArray()
        var trackCount = 0
        var cueCount = 0
        val uriKeys = (prefs.all.keys.filter { it.startsWith("content://") } +
            prefs.all.keys.filter { it.startsWith("track:content://") }.map { it.removePrefix("track:") })
            .distinct().sorted()
        val usedNames = mutableSetOf<String>()

        for (uriString in uriKeys) {
            val audioUri = runCatching { Uri.parse(uriString) }.getOrNull() ?: continue
            val cueString = prefs.getString(uriString, null)
            val positions = cueString?.split(',')?.map { it.toLongOrNull() ?: -1L }?.take(8)
                ?: List(8) { -1L }

            val sourceName = queryDisplayName(context, audioUri) ?: audioUri.lastPathSegment
                ?.substringAfterLast('/') ?: "audio_${trackCount + 1}.mp3"
            val baseName = sanitizeFilename(sourceName)
            var safeName = baseName
            var suffix = 2
            while (!usedNames.add(safeName.lowercase(Locale.ROOT))) {
                val dot = baseName.lastIndexOf('.')
                safeName = if (dot > 0) baseName.substring(0, dot) + " ($suffix)" + baseName.substring(dot)
                    else "$baseName ($suffix)"
                suffix++
            }
            val destination = musicDir.findFile(safeName)?.takeIf { it.isFile }
                ?: musicDir.createFile(mimeFor(safeName), safeName)
                ?: error("No se pudo crear $safeName en Music")

            val digest = MessageDigest.getInstance("SHA-256")
            context.contentResolver.openInputStream(audioUri)?.use { input ->
                destination.openOutputStream(context)?.use { output ->
                    val buffer = ByteArray(256 * 1024)
                    BufferedInputStream(input).use { buffered ->
                        while (true) {
                            val read = buffered.read(buffer)
                            if (read < 0) break
                            output.write(buffer, 0, read)
                            digest.update(buffer, 0, read)
                        }
                    }
                    output.flush()
                } ?: error("No se pudo abrir el destino USB para $safeName")
            } ?: error("Android no permite leer el archivo $sourceName. Vuelve a seleccionarlo.")

            val cueArray = JSONArray()
            positions.forEachIndexed { index, positionMs ->
                if (positionMs >= 0L) {
                    cueArray.put(JSONObject().apply {
                        put("number", index + 1)
                        put("position_ms", positionMs)
                        put("name", "CUE ${index + 1}")
                        put("color_argb", cueColors[index].toLong() and 0xFFFFFFFFL)
                    })
                    cueCount++
                }
            }
            val bpm = prefs.getString("bpm:$uriString", null)?.toDoubleOrNull()
            val trackJson = JSONObject().apply {
                put("relativePath", "Music/$safeName")
                put("filename", safeName)
                put("sha256", digest.digest().joinToString("") { "%02x".format(it) })
                if (bpm != null && bpm.isFinite()) put("bpm", bpm)
                put("cues", cueArray)
            }
            tracksJson.put(trackJson)
            trackCount++
        }

        if (trackCount == 0) error("No hay canciones registradas para exportar. Carga primero las pistas en IMPERIO BPM Studio.")

        val manifest = JSONObject().apply {
            put("format", "IMPERIO_CUE")
            put("version", 1)
            put("createdAt", System.currentTimeMillis())
            put("tracks", tracksJson)
        }
        val manifestFile = imperioDir.findFile("cues.json")
            ?: imperioDir.createFile("application/json", "cues.json")
            ?: error("No se pudo crear IMPERIO/cues.json")
        manifestFile.openOutputStream(context)?.bufferedWriter(Charsets.UTF_8)?.use {
            it.write(manifest.toString(2))
        } ?: error("No se pudo escribir IMPERIO/cues.json")

        return UsbExportResult(trackCount, cueCount)
    }

    private fun DocumentFile.openOutputStream(context: Context) =
        context.contentResolver.openOutputStream(uri, "wt")

    private fun queryDisplayName(context: Context, uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
    }.getOrNull()

    private fun sanitizeFilename(name: String): String {
        val cleaned = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().trim('.')
        return cleaned.ifBlank { "audio_${System.currentTimeMillis()}.mp3" }
    }

    private fun mimeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
        "mp3" -> "audio/mpeg"
        "wav" -> "audio/wav"
        "flac" -> "audio/flac"
        "m4a", "mp4" -> "audio/mp4"
        "aac" -> "audio/aac"
        "ogg", "opus" -> "audio/ogg"
        "wma" -> "audio/x-ms-wma"
        else -> "application/octet-stream"
    }
}
