package com.imperio.bpmstudio

import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private val Bg = Color(0xFF090B10)
private val Panel = Color(0xFF151923)
private val Violet = Color(0xFF9B6BFF)
private val Green = Color(0xFF42E6A4)
private val Muted = Color(0xFF8D96A8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ImperioApp() }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ImperioApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("imperio_cues", 0) }
    val player = remember { ExoPlayer.Builder(context).build() }
    var audioUri by remember { mutableStateOf<Uri?>(null) }
    var trackName by remember { mutableStateOf("Ninguna canción cargada") }
    var isPlaying by remember { mutableStateOf(false) }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }
    var bpm by remember { mutableStateOf("--.-") }
    var isAnalyzing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("Listo para cargar música") }
    var isExporting by remember { mutableStateOf(false) }
    var showUsbPreflight by remember { mutableStateOf(false) }
    var cues by remember { mutableStateOf(List(8) { -1L }) }
    var cueLabels by remember { mutableStateOf(List(8) { "CUE ${it + 1}" }) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) duration = player.duration.coerceAtLeast(0L)
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener); player.release() }
    }

    LaunchedEffect(player) {
        while (true) {
            if (player.isPlaying) position = player.currentPosition
            delay(150)
        }
    }

    val usbPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri ->
        if (treeUri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                scope.launch {
                    isExporting = true
                    status = "Preparando exportación USB…"
                    try {
                        val result = withContext(Dispatchers.IO) {
                            UsbExporter.exportAll(context, prefs, treeUri)
                        }
                        status = "VirtualDJ actualizado: ${result.exportedTracks} pistas, ${result.exportedCues} CUE nuevos, ${result.preservedCues} CUE existentes conservados. Respaldo: ${result.backupName}. ${result.unmatchedTracks} pistas sin coincidencia."
                    } catch (error: Exception) {
                        status = "Error al exportar: ${error.message ?: "no se pudo escribir en el USB"}"
                    } finally { isExporting = false }
                }
            } catch (error: Exception) {
                status = "No se pudo obtener permiso de escritura para el USB."
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) { }
            audioUri = uri
            prefs.edit().putBoolean("track:$uri", true).commit()
            trackName = uri.lastPathSegment?.substringAfterLast('/') ?: "Archivo de audio"
            player.setMediaItem(MediaItem.fromUri(uri))
            player.prepare()
            duration = 0L
            position = 0L
            val stored = prefs.getString(uri.toString(), null)
            cues = stored?.split(",")?.mapNotNull { it.toLongOrNull() }
                ?.take(8)?.let { parsed -> parsed + List(8 - parsed.size) { -1L } }
                ?: List(8) { -1L }
            cueLabels = List(8) { "CUE ${it + 1}" }
            bpm = prefs.getString("bpm:${uri}", null) ?: "--.-"
            status = if (cues.any { it >= 0L }) "Canción cargada. ${cues.count { it >= 0L }} CUE recuperados." else "Canción cargada. Presiona reproducir."
        }
    }

    fun persistCues(updatedCues: List<Long>) {
        val key = audioUri?.toString() ?: return
        // Commit synchronously so a rapid app close cannot lose the last cue edit.
        val saved = prefs.edit().putString(key, updatedCues.joinToString(",")).commit()
        status = if (saved) "${updatedCues.count { it >= 0L }} puntos CUE guardados en este dispositivo." else "No se pudieron guardar los CUE. Revisa el almacenamiento."
    }

    fun analyzeBpm() {
        val uri = audioUri ?: return
        scope.launch {
            isAnalyzing = true
            status = "Analizando audio…"
            try {
                val result = withContext(Dispatchers.IO) { BpmAnalyzer.analyze(context, uri) }
                bpm = String.format(Locale.US, "%.1f", result)
                prefs.edit().putString("bpm:${uri}", bpm).commit()
                status = "Análisis terminado. Verifica el tempo escuchando la pista."
            } catch (error: Exception) {
                status = error.message ?: "No se pudo analizar el BPM de esta pista."
            } finally { isAnalyzing = false }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Violet,
            secondary = Green, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Column(
            Modifier.fillMaxSize().background(Bg).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("IMPERIO", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Text("BPM STUDIO", color = Violet, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                }
                Surface(color = Panel, shape = RoundedCornerShape(12.dp)) {
                    Text("v0.4.0", color = Muted, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), fontSize = 11.sp)
                }
            }

            Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("REPRODUCTOR", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text(trackName, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilledTonalButton(onClick = { picker.launch(arrayOf("audio/*")) }) {
                            Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Cargar música")
                        }
                        Text(if (audioUri == null) "Sin archivo" else "Audio listo", color = Green, fontSize = 12.sp)
                    }
                    Slider(
                        value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f,
                        onValueChange = { position = it.toLong() },
                        onValueChangeFinished = { if (duration > 0) player.seekTo(position) },
                        valueRange = 0f..(duration.coerceAtLeast(1L).toFloat()),
                        colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Violet)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(formatTime(position), color = Muted, fontSize = 11.sp)
                        Text(formatTime(duration), color = Muted, fontSize = 11.sp)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { player.seekTo(0); player.pause() }) { Icon(Icons.Default.Stop, null, tint = Muted) }
                        FilledIconButton(
                            onClick = { if (player.isPlaying) player.pause() else if (audioUri != null) player.play() },
                            enabled = audioUri != null,
                            modifier = Modifier.size(58.dp),
                            colors = IconButtonDefaults.filledIconButtonColors(containerColor = Violet)
                        ) {
                            Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, modifier = Modifier.size(34.dp))
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.weight(1f)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("BPM", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                        Text(bpm, color = Green, fontSize = 34.sp, fontWeight = FontWeight.Black)
                        Text(if (isAnalyzing) "Analizando audio…" else "Tempo detectado desde el audio", color = Muted, fontSize = 10.sp)
                        TextButton(onClick = { analyzeBpm() }, enabled = audioUri != null && !isAnalyzing, contentPadding = PaddingValues(0.dp)) {
                            Text(if (isAnalyzing) "ANALIZANDO" else "ANALIZAR BPM", color = Green, fontSize = 10.sp)
                        }
                    }
                }
                Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.weight(1f)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("PUNTOS CUE", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                        Text("${cues.count { it >= 0L }} / 8", color = Violet, fontSize = 34.sp, fontWeight = FontWeight.Black)
                        Text("Marcas de esta canción", color = Muted, fontSize = 10.sp)
                    }
                }
            }

            Text("HOT CUES", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(cues) { index, cue ->
                    val active = cue >= 0L
                    Surface(
                        color = if (active) Color(0xFF30234D) else Panel,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.aspectRatio(1.1f).combinedClickable(
                            onClick = {
                            if (audioUri != null) {
                                if (active) player.seekTo(cue) else {
                                    val updated = cues.toMutableList()
                                    updated[index] = player.currentPosition
                                    cues = updated
                                    persistCues(updated)
                                }
                            }},
                            onLongClick = {
                                if (audioUri != null && active) {
                                    val updated = cues.toMutableList().also { it[index] = -1L }
                                    cues = updated
                                    persistCues(updated)
                                }
                            }
                        )
                    ) {
                        Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Text("${index + 1}", color = if (active) Green else Violet, fontSize = 23.sp, fontWeight = FontWeight.Black)
                            Text(if (active) formatTime(cue) else "SET CUE", color = Muted, fontSize = 10.sp)
                        }
                    }
                }
            }

            Button(
                onClick = { showUsbPreflight = true },
                enabled = !isExporting,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color(0xFF07110D))
            ) {
                Text(if (isExporting) "EXPORTANDO…" else "APLICAR HOT CUE A VIRTUALDJ USB", fontWeight = FontWeight.Bold)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { val empty = List(8) { -1L }; cues = empty; persistCues(empty) }, modifier = Modifier.weight(1f)) {
                    Text("Limpiar")
                }
                Button(onClick = { persistCues(cues) }, modifier = Modifier.weight(1f), enabled = audioUri != null) {
                    Text("Guardar CUE")
                }
            }
            Text(status, color = Muted, fontSize = 11.sp)
            Text("Mantén pulsado un HOT CUE para eliminarlo. Primero inicializa el pendrive en VirtualDJ 2025; después selecciona aquí su carpeta raíz.", color = Muted, fontSize = 10.sp)
            if (showUsbPreflight) {
                AlertDialog(
                    onDismissRequest = { showUsbPreflight = false },
                    title = { Text("Preparar pendrive VirtualDJ") },
                    text = { Text("Antes de continuar: conecta el pendrive a VirtualDJ 2025, cataloga la música y cierra VirtualDJ completamente. IMPERIO no crea la base de datos; modificará VirtualDJ/database.xml y guardará una copia de seguridad. ¿El pendrive ya fue inicializado y VirtualDJ está cerrado?") },
                    confirmButton = {
                        TextButton(onClick = { showUsbPreflight = false; usbPicker.launch(null) }) { Text("Sí, continuar") }
                    },
                    dismissButton = {
                        TextButton(onClick = { showUsbPreflight = false }) { Text("Cancelar") }
                    }
                )
            }
            Text("Creado por Dj Lucas Quintana", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

private fun formatTime(ms: Long): String {
    val seconds = (ms.coerceAtLeast(0L) / 1000L)
    return String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)
}
