# IMPERIO BPM Studio 0.5.0

Aplicación Android para preparar pistas, guardar hasta ocho Hot CUE por canción y escribir esos puntos directamente en la base de datos de VirtualDJ 2025 que ya existe en un pendrive.

## Novedades de 0.5.0 — Integración directa con VirtualDJ

- Se elimina la dependencia de IMPERIO VDJ SYNC para aplicar los Hot CUE.
- El exportador busca `VirtualDJ/database.xml` en la raíz del pendrive seleccionado.
- No crea ni inicializa una base de datos VirtualDJ: exige que VirtualDJ 2025 haya reconocido/catalogado previamente el USB.
- Relaciona cada canción de IMPERIO con una entrada `<Song>` por sufijo de ruta `Music/nombre` y tamaño de archivo cuando Android lo informa.
- Inserta `<Poi Type="cue">` con posición en segundos, número, nombre y color ARGB.
- Si ya existe un Hot CUE con el mismo número, lo conserva y no lo reemplaza.
- Crea una copia en `VirtualDJ/Backup/` antes de modificar el XML.
- Valida el XML original y el resultado antes de escribir.
- Muestra cuántas pistas se actualizaron, cuántos CUE nuevos se agregaron, cuántos se conservaron y cuántas pistas no pudieron asociarse.

## Flujo obligatorio de trabajo

1. Copia primero la música al pendrive, dentro de `Music/` (o conserva allí la estructura que ya catalogaste).
2. Conecta el pendrive a una PC con VirtualDJ 2025.
3. En VirtualDJ, navega hasta la música del pendrive, agrégala a la base de datos y deja que termine el análisis.
4. Confirma que exista `PENDRIVE/VirtualDJ/database.xml`.
5. Cierra VirtualDJ completamente y expulsa el pendrive de forma segura.
6. Conecta el pendrive al teléfono mediante USB OTG.
7. Abre IMPERIO BPM Studio, carga las mismas canciones (deben corresponder a los archivos del pendrive y tener el mismo tamaño) y marca los Hot CUE.
8. Pulsa **APLICAR HOT CUE A VIRTUALDJ USB** y selecciona la raíz del pendrive.
9. Espera el mensaje final y expulsa el pendrive de forma segura.
10. Conecta nuevamente el pendrive a la PC y abre VirtualDJ.

## Estructura esperada

```text
PENDRIVE/
├── Music/
│   ├── Tema 01.mp3
│   └── Tema 02.mp3
└── VirtualDJ/
    ├── database.xml       # creado y mantenido por VirtualDJ
    └── Backup/
        └── database.xml.imperio-AAAAmmdd-HHmmss.bak
```

## Reglas de seguridad y límites

- **VirtualDJ debe estar cerrado** antes de conectar el pendrive al teléfono. Android no puede comprobar de forma fiable si VirtualDJ está ejecutándose en la PC.
- El exportador nunca crea `VirtualDJ/database.xml`.
- Si no encuentra una única canción coincidente, la omite; no inventa una entrada nueva ni adivina por nombre ambiguo.
- Si el tamaño de archivo está disponible, también debe coincidir con `FileSize`.
- Los CUE existentes con el mismo número se conservan. Esta versión no ofrece sobrescritura automática.
- La escritura por Android Storage Access Framework no garantiza una operación atómica en todos los fabricantes. Se crea primero un respaldo fechado; prueba inicialmente con un pendrive no crítico.
- La base de datos se modifica externamente. VirtualDJ advierte que la escritura por aplicaciones externas puede corromperla y no ofrece soporte para ese uso. Mantén siempre el respaldo.
- Esta versión no modifica BPM, beatgrid, loops ni otros POI. Solo agrega Hot CUE.
- Los nombres de CUE son `CUE 1` a `CUE 8`; la paleta de colores es fija en esta versión.

## Compilar desde GitHub Actions

El workflow `.github/workflows/android.yml` compila `:app:assembleDebug` con JDK 17 y Gradle 8.9 y publica el APK como Artifact.

## Compilación local

Requiere JDK 17, Android SDK 35 y Gradle compatible con Android Gradle Plugin 8.7.3.

```bash
gradle --no-daemon :app:assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Estado de validación

Este paquete contiene el código fuente. No se ha ejecutado una compilación Android ni una prueba real sobre un pendrive y VirtualDJ 2025 en este entorno. La compatibilidad final debe verificarse con un pendrive de prueba y una copia de seguridad de la base de datos.


## Novedades 0.5.0
- Vista de forma de onda calculada desde el audio decodificado (no es una imagen decorativa).
- El progreso de reproducción se dibuja sobre la onda y se puede tocar para buscar una posición.
- El análisis BPM se inicia automáticamente al cargar una pista y se ejecuta en segundo plano.
- BPM y forma de onda se calculan en el mismo análisis para evitar decodificar dos veces.
- El análisis manual sigue disponible como alternativa.
