package com.imperio.bpmstudio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

data class AudioAnalysisResult(val bpm: Double?, val waveform: List<Float>)

/** Decodes selected audio once, estimating tempo and building a normalized overview waveform. */
object BpmAnalyzer {
    fun analyze(context: Context, uri: Uri): Double = analyzeWithWaveform(context, uri).bpm
        ?: throw IllegalArgumentException("No se pudo detectar un BPM estable en esta pista.")

    fun analyzeWithWaveform(context: Context, uri: Uri): AudioAnalysisResult {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        val envelope = ArrayList<Double>()
        try {
            extractor.setDataSource(context, uri, null)
            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val candidate = extractor.getTrackFormat(i)
                val mime = candidate.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) { track = i; format = candidate; break }
            }
            require(track >= 0 && format != null) { "No se encontró una pista de audio compatible." }
            extractor.selectTrack(track)
            val mime = format!!.getString(MediaFormat.KEY_MIME)!!
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var sampleRate = format!!.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format!!.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var pcmEncoding = 2 // AudioFormat.ENCODING_PCM_16BIT
            var frameSamples = max(1, sampleRate / 100) * channels
            var absSum = 0.0
            var sampleCount = 0

            while (!outputDone) {
                if (!inputDone) {
                    val inputIndex = codec.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val input = codec.getInputBuffer(inputIndex)!!
                        input.clear()
                        val size = extractor.readSampleData(input, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                when (val outputIndex = codec.dequeueOutputBuffer(info, 10_000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val out = codec.outputFormat
                        sampleRate = out.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = out.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        pcmEncoding = if (out.containsKey(MediaFormat.KEY_PCM_ENCODING)) out.getInteger(MediaFormat.KEY_PCM_ENCODING) else 2
                        frameSamples = max(1, sampleRate / 100) * channels
                    }
                    MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                    else -> if (outputIndex >= 0) {
                        val buffer = codec.getOutputBuffer(outputIndex)
                        if (buffer != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            buffer.order(ByteOrder.LITTLE_ENDIAN)
                            if (pcmEncoding == 4) {
                                while (buffer.remaining() >= 4) {
                                    absSum += abs(buffer.float.toDouble())
                                    sampleCount++
                                    if (sampleCount >= frameSamples) {
                                        envelope.add(absSum / sampleCount)
                                        absSum = 0.0; sampleCount = 0
                                    }
                                }
                            } else {
                                while (buffer.remaining() >= 2) {
                                    absSum += abs(buffer.short.toInt() / 32768.0)
                                    sampleCount++
                                    if (sampleCount >= frameSamples) {
                                        envelope.add(absSum / sampleCount)
                                        absSum = 0.0; sampleCount = 0
                                    }
                                }
                            }
                        }
                        outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        codec.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }
            if (sampleCount > 0) envelope.add(absSum / sampleCount)
        } finally {
            try { codec?.stop() } catch (_: Exception) { }
            try { codec?.release() } catch (_: Exception) { }
            extractor.release()
        }
        val waveform = buildWaveform(envelope, 420)
        val bpm = try { estimateFromEnvelope(envelope) } catch (_: IllegalArgumentException) { null }
        return AudioAnalysisResult(bpm, waveform)
    }

    private fun buildWaveform(values: List<Double>, bars: Int): List<Float> {
        if (values.isEmpty()) return emptyList()
        val chunk = (values.size.toDouble() / bars).coerceAtLeast(1.0)
        return (0 until bars).map { index ->
            val start = (index * chunk).toInt().coerceAtMost(values.size - 1)
            val end = ((index + 1) * chunk).toInt().coerceAtMost(values.size).coerceAtLeast(start + 1)
            values.subList(start, end).maxOrNull()?.toFloat() ?: 0f
        }.let { result ->
            val peak = result.maxOrNull()?.coerceAtLeast(1e-6f) ?: 1f
            result.map { (it / peak).coerceIn(0.04f, 1f) }
        }
    }

    private fun estimateFromEnvelope(values: List<Double>): Double {
        require(values.size >= 800) { "El audio es demasiado corto para analizarlo con fiabilidad (se necesitan unos 8 segundos)." }
        // Positive energy changes emphasize drum and percussion attacks.
        val onset = DoubleArray(values.size)
        for (i in 1 until values.size) onset[i] = max(0.0, values[i] - values[i - 1])
        val mean = onset.average()
        for (i in onset.indices) onset[i] -= mean

        val minLag = 60.0 * 100.0 / 180.0
        val maxLag = 60.0 * 100.0 / 70.0
        var bestLag = 0
        var bestScore = Double.NEGATIVE_INFINITY
        for (lag in minLag.toInt()..maxLag.toInt()) {
            var score = 0.0
            var normA = 0.0
            var normB = 0.0
            var i = lag
            while (i < onset.size) {
                val a = onset[i]
                val b = onset[i - lag]
                score += a * b
                normA += a * a
                normB += b * b
                i++
            }
            val normalized = score / (sqrt(normA * normB) + 1e-12)
            if (normalized > bestScore) { bestScore = normalized; bestLag = lag }
        }
        require(bestLag > 0 && bestScore > 0.03) { "No se pudo detectar un pulso estable en este audio." }
        return 6000.0 / bestLag
    }
}
