package com.imperio.bpmstudio

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import org.w3c.dom.Document
import org.w3c.dom.Element
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

internal data class UsbExportResult(
    val exportedTracks: Int,
    val exportedCues: Int,
    val preservedCues: Int,
    val backupName: String,
    val unmatchedTracks: Int
)

/**
 * Updates an EXISTING VirtualDJ USB database. It never creates a VirtualDJ database.
 * VirtualDJ must have catalogued the music on this drive first and must be closed.
 */
internal object UsbExporter {
    private val cueColors = listOf(
        0xFFFF5252.toLong() and 0xFFFFFFFFL,
        0xFFFFB300.toLong() and 0xFFFFFFFFL,
        0xFF76FF03.toLong() and 0xFFFFFFFFL,
        0xFF00E5FF.toLong() and 0xFFFFFFFFL,
        0xFF448AFF.toLong() and 0xFFFFFFFFL,
        0xFFE040FB.toLong() and 0xFFFFFFFFL,
        0xFFFFFFFF.toLong() and 0xFFFFFFFFL,
        0xFF69F0AE.toLong() and 0xFFFFFFFFL
    )

    fun exportAll(context: Context, prefs: android.content.SharedPreferences, treeUri: Uri): UsbExportResult {
        val root = DocumentFile.fromTreeUri(context, treeUri)
            ?: error("No se pudo abrir el pendrive seleccionado")
        if (!root.canWrite()) error("El pendrive no permite escritura")

        val vdjDir = root.findFile("VirtualDJ")?.takeIf { it.isDirectory }
            ?: error("No se encontró VirtualDJ/ en el pendrive. Conecta primero el USB a VirtualDJ 2025, agrega/analiza la música y vuelve a conectarlo al teléfono.")
        val database = vdjDir.findFile("database.xml")?.takeIf { it.isFile }
            ?: error("No existe VirtualDJ/database.xml. VirtualDJ debe inicializar el pendrive primero.")
        if (!database.canWrite()) error("VirtualDJ/database.xml no permite escritura")

        val originalBytes = context.contentResolver.openInputStream(database.uri)?.use { it.readBytes() }
            ?: error("No se pudo leer VirtualDJ/database.xml")
        val document = parseXml(originalBytes)
        val documentRoot = document.documentElement
        if (documentRoot.tagName != "VirtualDJ_Database") error("El archivo no parece una base de datos de VirtualDJ")

        val songNodes = documentRoot.getElementsByTagName("Song")
        val songs = (0 until songNodes.length).mapNotNull { songNodes.item(it) as? Element }
        if (songs.isEmpty()) error("La base de datos existe, pero no contiene canciones. Vuelve a catalogar la música en VirtualDJ.")

        val uriKeys = prefs.all.keys.filter { it.startsWith("content://") && prefs.getBoolean("track:$it", false) }
            .distinct().sorted()
        if (uriKeys.isEmpty()) error("No hay canciones cargadas en IMPERIO BPM Studio")

        var exportedTracks = 0
        var exportedCues = 0
        var preservedCues = 0
        val unresolved = mutableListOf<String>()

        for (uriString in uriKeys) {
            val audioUri = Uri.parse(uriString)
            val sourceName = queryString(context, audioUri, OpenableColumns.DISPLAY_NAME)
                ?: audioUri.lastPathSegment?.substringAfterLast('/') ?: "audio"
            val sourceSize = queryLong(context, audioUri, OpenableColumns.SIZE)
            val cues = prefs.getString(uriString, null)?.split(',')?.map { it.toLongOrNull() ?: -1L }
                ?.take(8) ?: List(8) { -1L }
            if (cues.none { it >= 0L }) continue

            // Match by the path suffix VirtualDJ recorded on the USB, and require file size when available.
            val expectedSuffix = "/Music/${sourceName}".replace('\\', '/').lowercase(Locale.ROOT)
            val candidates = songs.filter { song ->
                val path = song.getAttribute("FilePath").replace('\\', '/').lowercase(Locale.ROOT)
                val pathMatch = path.endsWith(expectedSuffix) || path == "music/${sourceName.lowercase(Locale.ROOT)}"
                val sizeMatch = sourceSize == null || song.getAttribute("FileSize").toLongOrNull() == sourceSize
                pathMatch && sizeMatch
            }
            if (candidates.size != 1) {
                unresolved += "$sourceName (${if (candidates.isEmpty()) "no encontrada" else "coincidencia ambigua"})"
                continue
            }

            val song = candidates.single()
            for (index in cues.indices) {
                val positionMs = cues[index]
                if (positionMs < 0L) continue
                val cueNumber = index + 1
                val existing = directPoiChildren(song).filter {
                    it.getAttribute("Type").equals("cue", true) && it.getAttribute("Num").toIntOrNull() == cueNumber
                }
                if (existing.isNotEmpty()) {
                    preservedCues++ // Never overwrite an existing VirtualDJ cue automatically.
                    continue
                }
                val poi = document.createElement("Poi")
                poi.setAttribute("Type", "cue")
                if (positionMs > 0L) poi.setAttribute("Pos", String.format(Locale.US, "%.6f", positionMs / 1000.0))
                poi.setAttribute("Name", "CUE $cueNumber")
                poi.setAttribute("Num", cueNumber.toString())
                poi.setAttribute("Color", cueColors[index].toString())
                song.appendChild(poi)
                exportedCues++
            }
            exportedTracks++
        }

        if (exportedTracks == 0) {
            val detail = unresolved.take(5).joinToString("; ")
            error("No se pudo asociar ninguna canción con la base de VirtualDJ. Verifica que la música esté en Music/ y que VirtualDJ la haya catalogado. $detail")
        }

        val updatedBytes = serializeXml(document)
        // Validate the complete output before touching the original file.
        parseXml(updatedBytes)

        val backupDir = vdjDir.findFile("Backup")?.takeIf { it.isDirectory }
            ?: vdjDir.createDirectory("Backup") ?: error("No se pudo crear VirtualDJ/Backup")
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val backupName = "database.xml.imperio-$stamp.bak"
        val backup = backupDir.createFile("application/octet-stream", backupName)
            ?: error("No se pudo crear la copia de seguridad")
        context.contentResolver.openInputStream(database.uri)?.use { input ->
            backup.openOutputStream(context)?.use { output -> input.copyTo(output) }
                ?: error("No se pudo escribir la copia de seguridad")
        } ?: error("No se pudo volver a leer la base original para respaldarla")

        // SAF providers do not guarantee atomic rename. The timestamped backup is completed first.
        context.contentResolver.openOutputStream(database.uri, "wt")?.use { it.write(updatedBytes); it.flush() }
            ?: error("No se pudo actualizar database.xml. La copia de seguridad quedó en $backupName")

        return UsbExportResult(exportedTracks, exportedCues, preservedCues, backupName, unresolved.size)
    }

    private fun directPoiChildren(song: Element): List<Element> {
        val result = mutableListOf<Element>()
        val children = song.childNodes
        for (i in 0 until children.length) (children.item(i) as? Element)?.let { if (it.tagName == "Poi") result += it }
        return result
    }

    private fun parseXml(bytes: ByteArray): Document {
        val factory = DocumentBuilderFactory.newInstance()
        factory.isNamespaceAware = false
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
        factory.setFeature("http://xml.org/sax/features/external-general-entities", false)
        factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false)
        factory.setExpandEntityReferences(false)
        return factory.newDocumentBuilder().parse(ByteArrayInputStream(bytes))
    }

    private fun serializeXml(document: Document): ByteArray {
        val output = ByteArrayOutputStream()
        val transformer = TransformerFactory.newInstance().newTransformer().apply {
            setOutputProperty(OutputKeys.ENCODING, "UTF-8")
            setOutputProperty(OutputKeys.INDENT, "yes")
            setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no")
        }
        transformer.transform(DOMSource(document), StreamResult(output))
        return output.toByteArray()
    }

    private fun DocumentFile.openOutputStream(context: Context) = context.contentResolver.openOutputStream(uri, "wt")

    private fun queryString(context: Context, uri: Uri, column: String): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(column), null, null, null)?.use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getString(0) else null
        }
    }.getOrNull()

    private fun queryLong(context: Context, uri: Uri, column: String): Long? = runCatching {
        context.contentResolver.query(uri, arrayOf(column), null, null, null)?.use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else null
        }
    }.getOrNull()
}
